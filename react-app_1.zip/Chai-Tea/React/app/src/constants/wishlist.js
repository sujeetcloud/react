import { images } from "../constants";

const wishlist = [
    {
        id: 1, 
        image: images.product1,
        name: 'Chamomile Tea',
        price: '$50.00',
        status: 'InStock',
    },
    {
        id: 2,
        image: images.product2,
        name: 'Peppermint Tea',
        price: '$50.00', 
        status: 'OutOfStock',
    },
    {
        id: 3,
        image: images.product3,
        name: 'Ginger Tea',
        price: '$50.00',
        status: 'OutOfStock',
    },
    {
        id: 4,
        image: images.product4,
        name: 'Hibiscus Tea',
        price: '$50.00',
        status: 'InStock',
    },
    {
        id: 5,
        image: images.product5,
        name: 'Rooibos Tea',
        price: '$50.00',
        status: 'InStock',
    },
];

export default wishlist;