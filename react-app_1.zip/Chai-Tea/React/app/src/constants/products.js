import { images } from '../constants';

const products = [

    {
        id: 1,
        image: images.product1, 
        name: 'Chamomile Tea',
        reviews: '100+', 
        price: '15.00',
        disprice: '12.00',
        availability: 'in stock',
        quantity: 1,
        content: 'Lorem, Ipsum Dolor Sit Amet Consectetur Adipisicing Elit. Quam, Quisquam Consectetur! Nulla Dicta Aperiam Necessitatibus, Ad Impedit Cupiditate Illum Possimus Placeat Unde At Deserunt Eum, Quas, Dignissimos Omnis Cum Fugit.',
        category: [
            'herbal tea',
            'green tea'
        ], 
        tags: [
            'black tea',
            'healthy',
            'organic'
        ],
        gallery: {
            image1: images.productGallery1,
            image2: images.productGallery2,
            image3: images.productGallery3,
            image4: images.productGallery4,
        }
    },
    {
        id: 2,
        image: images.product2,
        name: 'Peppermint Tea',
        price: '15.00',
        disprice: '12.00',
        availability: 'in stock',
        content: 'Lorem, Ipsum Dolor Sit Amet Consectetur Adipisicing Elit. Quam, Quisquam Consectetur! Nulla Dicta Aperiam Necessitatibus, Ad Impedit Cupiditate Illum Possimus Placeat Unde At Deserunt Eum, Quas, Dignissimos Omnis Cum Fugit.',
        reviews: '150+',
        category: [
            'herbal tea',
            'green tea'
        ], 
        tags: [
            'black tea',
            'healthy',
            'organic'
        ],
        gallery: {
            image1: images.productGallery1,
            image2: images.productGallery2,
            image3: images.productGallery3,
            image4: images.productGallery4,
        }
    }, 
    {
        id: 3,
        image: images.product3,
        name: 'Ginger Tea',
        price: '15.00',
        disprice: '12.00',
        availability: 'in stock',
        content: 'Lorem, Ipsum Dolor Sit Amet Consectetur Adipisicing Elit. Quam, Quisquam Consectetur! Nulla Dicta Aperiam Necessitatibus, Ad Impedit Cupiditate Illum Possimus Placeat Unde At Deserunt Eum, Quas, Dignissimos Omnis Cum Fugit.',
        reviews: '50+',
        category: [
            'herbal tea',
            'green tea'
        ], 
        tags: [
            'black tea',
            'healthy',
            'organic'
        ],
        gallery: {
            image1: images.productGallery1,
            image2: images.productGallery2,
            image3: images.productGallery3,
            image4: images.productGallery4,
        }
    },
    {
        id: 4,
        image: images.product4,
        name: 'Hibiscus Tea',
        price: '15.00',
        disprice: '12.00',
        availability: 'in stock',
        content: 'Lorem, Ipsum Dolor Sit Amet Consectetur Adipisicing Elit. Quam, Quisquam Consectetur! Nulla Dicta Aperiam Necessitatibus, Ad Impedit Cupiditate Illum Possimus Placeat Unde At Deserunt Eum, Quas, Dignissimos Omnis Cum Fugit.',
        reviews: '20+',
        category: [
            'herbal tea',
            'green tea'
        ], 
        tags: [
            'birthday', 
            'roses',
            'wedding'
        ],
        gallery: {
            image1: images.productGallery1,
            image2: images.productGallery2,
            image3: images.productGallery3,
            image4: images.productGallery4,
        }
    },
    {
        id: 5,
        image: images.product5,
        name: 'Rooibos Tea',
        price: '15.00',
        disprice: '12.00',
        availability: 'in stock',
        content: 'Lorem, Ipsum Dolor Sit Amet Consectetur Adipisicing Elit. Quam, Quisquam Consectetur! Nulla Dicta Aperiam Necessitatibus, Ad Impedit Cupiditate Illum Possimus Placeat Unde At Deserunt Eum, Quas, Dignissimos Omnis Cum Fugit.',
        reviews: '30+',
        category: [
            'herbal tea',
            'green tea'
        ], 
        tags: [
            'black tea',
            'healthy',
            'organic'
        ],
        gallery: {
            image1: images.productGallery1,
            image2: images.productGallery2,
            image3: images.productGallery3,
            image4: images.productGallery4,
        }
    },
    {
        id: 6,
        image: images.product6,
        name: 'Sage Tea',
        price: '15.00',
        disprice: '12.00',
        availability: 'in stock',
        content: 'Lorem, Ipsum Dolor Sit Amet Consectetur Adipisicing Elit. Quam, Quisquam Consectetur! Nulla Dicta Aperiam Necessitatibus, Ad Impedit Cupiditate Illum Possimus Placeat Unde At Deserunt Eum, Quas, Dignissimos Omnis Cum Fugit.',
        reviews: '60+',
        category: [
            'herbal tea',
            'green tea'
        ], 
        tags: [
            'black tea',
            'healthy',
            'organic'
        ],
        gallery: {
            image1: images.productGallery1,
            image2: images.productGallery2,
            image3: images.productGallery3,
            image4: images.productGallery4,
        }
    },
    {
        id: 7,
        image: images.product7,
        name: 'Lemon Balm Tea',
        price: '15.00',
        disprice: '12.00',
        availability: 'in stock',
        content: 'Lorem, Ipsum Dolor Sit Amet Consectetur Adipisicing Elit. Quam, Quisquam Consectetur! Nulla Dicta Aperiam Necessitatibus, Ad Impedit Cupiditate Illum Possimus Placeat Unde At Deserunt Eum, Quas, Dignissimos Omnis Cum Fugit.',
        reviews: '70+',
        category: [
            'herbal tea',
            'green tea'
        ], 
        tags: [
            'black tea',
            'healthy',
            'organic'
        ],
        gallery: {
            image1: images.productGallery1,
            image2: images.productGallery2,
            image3: images.productGallery3,
            image4: images.productGallery4,
        }
    },
    {
        id: 8,
        image: images.product8,
        name: 'Rose Hip Tea',
        price: '15.00',
        disprice: '12.00',
        availability: 'in stock',
        content: 'Lorem, Ipsum Dolor Sit Amet Consectetur Adipisicing Elit. Quam, Quisquam Consectetur! Nulla Dicta Aperiam Necessitatibus, Ad Impedit Cupiditate Illum Possimus Placeat Unde At Deserunt Eum, Quas, Dignissimos Omnis Cum Fugit.',
        reviews: '75+',
        category: [
            'herbal tea',
            'green tea'
        ], 
        tags: [
            'black tea',
            'healthy',
            'organic'
        ],
        gallery: {
            image1: images.productGallery1,
            image2: images.productGallery2,
            image3: images.productGallery3,
            image4: images.productGallery4,
        }
    },
    {
        id: 9,
        image: images.product9,
        name: 'Passionflower Tea',
        price: '15.00', 
        disprice: '12.00',
        availability: 'in stock',
        content: 'Lorem, Ipsum Dolor Sit Amet Consectetur Adipisicing Elit. Quam, Quisquam Consectetur! Nulla Dicta Aperiam Necessitatibus, Ad Impedit Cupiditate Illum Possimus Placeat Unde At Deserunt Eum, Quas, Dignissimos Omnis Cum Fugit.',
        reviews: '120+',
        category: [
            'herbal tea',
            'green tea'
        ], 
        tags: [
            'black tea',
            'healthy',
            'organic'
        ],
        gallery: {
            image1: images.productGallery1,
            image2: images.productGallery2,
            image3: images.productGallery3,
            image4: images.productGallery4,
        }
    },
 
];

export default products;