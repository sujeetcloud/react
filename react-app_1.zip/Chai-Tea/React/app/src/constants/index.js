{/*Global*/}
export { default as images } from './images';
export { default as navbar } from './navbar';

  
{/*Home*/}
export { default as homeContent } from './home';
export { latest, featured, bestSeller } from './productsFilter';
export { default as team } from './team';
export { default as testiContent } from './testiContent';


{/*About*/}
export { default as faqsContent } from './faqs';


{/*Pages*/}
export { herbal, chai, green, black } from './menu';
export { galleryContent } from './gallery';
export {  default as profile } from './profile';


{/*Blogs*/}
export { categories as blogCategories } from './blogSidebar';
export { posts, tags } from './blogSidebar';
export { default as blogContent } from './blogs';


{/*Shop*/} 
export { categories as shopCategories } from './shopSidebar';
export { popular as popularProducts } from './shopSidebar';
export { default as productsContent} from './products';
export { default as related} from './relatedItems';
export { default as wishlist} from './wishlist';
export { cartTotal, payment } from './checkout';
export { cartSummary, cartItems } from './cart';
export { default as orderlist} from './orderList';
export { items, address, orderSummary} from './orderDetails';


{/*Contact*/}
export { default as contactContent } from './contacts';
