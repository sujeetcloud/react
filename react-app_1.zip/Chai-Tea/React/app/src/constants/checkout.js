export const cartTotal = [
    {id: 1, name: 'sub total', value: '$200.00'},
    {id: 2, name: 'delivery fee', value: '$50.00'},
    {id: 3, name: 'discount', value: '$20.00'},
    {id: 4, name: 'tax', value: '$20.00'},
    {id: 5, name: 'total', value: '$250.00'},
];

export const payment = [
    {
        id: 1,
        paymentID: 'direct-bank-transfer',
        value: 'DIRECT',
        title: 'direct bank transfer',
        content: 'Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order won’t be shipped until the funds have our account.'
    },
    {
        id: 2,
        paymentID: 'cash-on-delivery',
        value: 'CASH',
        title: 'cash on delivery',
        content: 'Please send your cheque to Store Name, Store Street, Store Town, Store State / County, Store Postcode.'
    },
    {
        id: 3,
        paymentID: 'paypal',
        value: 'PAYPAL',
        title: 'paypal',
        content: 'Pay via PayPal; you can pay with your credit card if you don’t have a PayPal account.'
    },
];