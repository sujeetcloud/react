{/*Home*/}
export { default as HomePage } from './HomePage/HomePage';
export { default as Home } from './HomePage/Home/Home';
export { default as About } from './HomePage/About/About';
export { default as Counter } from './HomePage/Counter/Counter';  
export { default as Products } from './HomePage/Products/Products';
export { default as Team } from './HomePage/Team/Team';
export { default as Testimonials } from './HomePage/Testimonials/Testimonials';
export { default as Blogs } from './HomePage/Blogs/Blogs';
 

{/*About*/}
export { default as AboutUs } from './About/AboutUs/AboutUs';
export { default as Faqs } from './About/Faqs/Faqs';
export { default as TeamPage } from './About/TeamPage/TeamPage';
export { default as TestimonialsPage } from './About/TestimonialsPage/TestimonialsPage';


{/*Pages*/}
export { default as Menu } from './Pages/Menu/Menu';
export { default as Gallery } from './Pages/Gallery/Gallery';
export { default as Reservation } from './Pages/Reservation/Reservation';
export { default as Login } from './Pages/Login/Login';
export { default as Register } from './Pages/Register/Register';
export { default as ForgotPwd } from './Pages/ForgotPwd/ForgotPwd';
export { default as ChangePwd } from './Pages/ChangePwd/ChangePwd';
export { default as Profile } from './Pages/Profile/Profile';
export { default as EditProfile } from './Pages/EditProfile/EditProfile';
export { default as EditAddress } from './Pages/EditAddress/EditAddress';


{/*Blog*/}
export { default as BlogGrid } from './Blogs/BlogGrid/BlogGrid';
export { default as BlogList } from './Blogs/BlogList/BlogList';
export { default as BlogDetails } from './Blogs/BlogDetails/BlogDetails';


{/*Shop*/}
export { default as ShopGrid } from './Shop/ShopGrid/ShopGrid';
export { default as ShopList } from './Shop/ShopList/ShopList';
export { default as ProductDetails } from './Shop/ProductDetails/ProductDetails';
export { default as Wishlist } from './Shop/Wishlist/Wishlist';
export { default as Checkout } from './Shop/Checkout/Checkout';
export { default as Cart } from './Shop/Cart/Cart';
export { default as OrderList } from './Shop/OrderList/OrderList';
export { default as OrderDetails } from './Shop/OrderDetails/OrderDetails';

{/*Contact*/}
export { default as ContactUs } from './ContactUs/ContactUs';







